from Crypto.Cipher import AES
import os
from Crypto.Util.number import *

flag = os.urandom(18)
flag_enc = os.urandom(45)
pad = b'a' * 12 + b'Neepu{'
flag_enc = pad+flag_enc+b'}'
masg1 = flag_enc[0:32]
masg2 = flag_enc[32: ]

m = bytes_to_long(masg1)^bytes_to_long(masg2)
key = os.urandom(2)*16
iv = masg2[16:][:16]
print(bytes_to_long(key)^bytes_to_long(iv))
aes = AES.new(key,AES.MODE_CBC,iv)
enc_flag = aes.encrypt(long_to_bytes(m))
print(enc_flag)

'''
111074535590201916919246051309547040927554959486196038152130336189953949145068
b'\xd8\x83\xfd\x89\xc3+\x11\xb8g\xd2\xf5k\xeeU\x88\xb5\xde\x8bq\x9bC\xab\xe3K2R<\xaa\xbc\x92H\x19'
'''
