#!/bin/sh

echo $FLAG > /home/ctf/flag
chown root:ctf /home/ctf/flag

# start ctf-xinetd
/etc/init.d/xinetd start; 
trap : TERM INT; 
sleep infinity & wait