coin_list = ["BTC","ETH","DOT","XRP"]
raw_list=[54689,2251,33,1]
price_list = [54689.91,2251.09,33.5761,1.31706]
many_list = [0,0,0,0,0]

money = 10000

def buy(coin,many):
    global money
    many = int(many)
    if( price_list[coin_list.index(coin)]*many >money ):
        print("you don't have money")
        return "false"
    else:
        money = money - price_list[coin_list.index(coin)]*many
        price_list[coin_list.index(coin)] -= 0.0001*int(raw_list[coin_list.index(coin)])*many
        many_list[coin_list.index(coin)] += many 
    return "success"

def sell(coin):
    global money
    money = money + price_list[coin_list.index(coin)]*many_list[coin_list.index(coin)]
    many_list[coin_list.index(coin)]=0
    return "success"
    

while(1):
    print("This is the coin market, you need to use your intelligence to earn a million to get the flag")
    print("your have: ")
    print("BTC: "+str(many_list[0])+"   ETH:"+str(many_list[1])+"   DOT:"+str(many_list[2])+"   XRP:"+str(many_list[3])+"   money:"+str(money) )
    print("\n1.view price")
    print("2.purchase")
    print("3.sell out")

    choice = input("Please enter your choice:\n>>>")
    if(choice == "1"):
        print("BTC: "+str(price_list[0])+"   ETH:"+str(price_list[1])+"   DOT:"+str(price_list[2])+"   XRP:"+str(price_list[3]) )
    if(choice == "2"):
        print("What do you want to buy ?")
        tmp_coin = input(">>>")
        if tmp_coin in coin_list:
            print("How many "+tmp_coin+" do you want to buy ?")
            tmp_many = input(">>>")
            if tmp_many.isdigit():
                print(buy(tmp_coin,tmp_many))
        else:
            print("We don't have this")
    if(choice == "3"):
        print("What do you want to sell ?")
        tmp_coin = input(">>>")
        if tmp_coin in coin_list:
            print(sell(tmp_coin))
        else:
            print("You don't have this")
    if(money>1000000):
        print(open('flag').read())

    input("\nEnter any key to continue...\n\n")