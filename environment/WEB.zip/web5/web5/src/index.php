<title>neepu_sec.club</title>
<body background="bg.jpg">
<font color="green"><h1>Welcome to neepu sec club, try to upload your content :)</h1></font>
<font size = 5><p>Here is <a href="source.php">source</a> and <a href="uploads/sample/sample.txt">sample</a></p></font>
<?php
error_reporting(0);
$uploadclub = (isset($_SERVER['HTTP_X_FORWARDED_FOR']) ? $_SERVER['HTTP_X_FORWARDED_FOR'] : md5($_SERVER['REMOTE_ADDR']));
$uploadclub = basename(str_replace(['.','-','(','`','<'],['','','','',''], $uploadclub));
@mkdir('uploads/'.$uploadclub);
@chdir('uploads/'.$uploadclub);
print_r("Upload: uploads/".$uploadclub);
$check = file_get_contents('php://input');
if(preg_match('/25/', $check)) {
    die("<br />No more 25 :(");
}else {
    extract($_POST);
    foreach ($_POST as $key => $value) {
        $key = $value;
    }
}
if(isset($_POST['neepu_sec.club'])) {
    $content = $key;
    if(preg_match('/iconv|UCS|UTF|rot|quoted|base64|zlib|string|tripledes|ini|htaccess|\\|#|\<\?/i', $content)) {
        die('<br />hacker!!!');
    }
    $content = str_replace('.php','neepu',$content);
    $content = str_replace('.phtml','neepu',$content);
    file_put_contents($content,'<?php exit();'.$content);
    chdir('..');
    if(!stripos(file_get_contents($content),'<?') && !stripos(file_get_contents($content),'php') && !stripos(file_get_contents($content),'=')) {
        require_once($content);
    }
}else {
    chdir(__DIR__);
    @rmdir('uploads/'.$uploadclub);
}
?>