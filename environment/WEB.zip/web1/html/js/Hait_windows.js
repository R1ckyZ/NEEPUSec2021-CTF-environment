{"data":[
	{"id":1,"iconName":"FireFox","iconUrl":"Hait_images/ico/4.png","url":"http://www.baidu.com","width":700,"height":500,"resize":true},{"id":2,"iconName":"IEBrowser","iconUrl":"Hait_images/ico/8.png","url":"notfound.html","width":700,"height":500,"resize":true},
	{"id":30,"iconName":"刷新桌面","iconUrl":"img/shortcut/news.png","url":"刷新桌面.html","width":500,"height":300,"resize":false}
]}