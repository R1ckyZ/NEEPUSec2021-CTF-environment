//回到顶部
function scrollTop(){
	$("html,body").animate({scrollTop:0},500);
	return false;
}