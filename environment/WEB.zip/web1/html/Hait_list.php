﻿<?php
error_reporting(0);
require 'config.php';
$id=$_GET["id"]; 
$page= $_GET["page"]; 
require_once'Hait_app/Hait_function.php';
$mode="where huishou<>1 and channel='$id' and shenhe=1";
$rows = mysql_num_rows(mysql_query("select * from hait_article $mode",$conn)); 
Page($rows,60,$id); 
$sql = "select * from hait_article $mode order by id desc limit $select_from $select_limit"; 
$query= mysql_query($sql,$conn); 
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="Hait_images/hait_windows.css" />
<link rel="stylesheet" type="text/css" href="Hait_images/hait_menu.css" />
<link rel="stylesheet" href="js/jquery.HooRay/jquery.HooRay.css">
<style>*{font-size:12px}</style>
<script src="js/jquery-1.7.min.js"></script>
<script src="js/jquery.HooRay/jquery.HooRay.js"></script>
<script src="js/shortcut.js"></script>
<script src="js/templates.js"></script>
<script src="js/core.js"></script>
</head>
<body>
<table width="100%" border="0">
  <tr>
    <td align="left" valign="top">
  <?php while($dbq_rec = mysql_fetch_array($query)){
  $t1 = $dbq_rec['pic'];
  $t2 = $dbq_rec['title'];
  $t3=GBsubstr($t2, 0, 20);
  $articleid = $dbq_rec['id'];
  $width = $dbq_rec['width'];
  $height = $dbq_rec['height'];
  if($dbq_rec['url']==""){$url='hait_show.php?id='.$id.'';}else{$url=$dbq_rec['url'];}
  if($dbq_rec['lashen']==1){$lashen="true";}else{$lashen="false";}
?>    
  <div class="pre_view" align="center">
    <script>
   function showinfo<?php echo $articleid;?>(){
	window.parent.Core.create("",{title:"<?php echo $t2;?>",url:"<?php echo $url;?>",width:<?php echo $width;?>,height:<?php echo $height;?>,resize:<?php echo $lashen;?>});
}
    </script>
    <script>
function city(){
var ai=document.body.offsetWidth;
document.getElementById('view').innerHTML = ai;

}
</script>
    <table width="100" height="120"  align="center">
      <tr><td width="95" height="70" align="center" ><a href="#" onclick="showinfo<?php echo $articleid;?>()" title="<?php echo $t2;?>"><img src="<?php echo $t1;?>" width="40" height="40" border="0" onerror="this.src='hait_images/emptybook.gif'"/></a></td>
      </tr>
      <tr><td align="center" valign="top" class="title" ><a href="Hait_show.php?id=<?php echo $articleid;?>" title="<?php echo $t2;?>"><?php echo $t3;?></a></td>
      </tr>
      </table>
  </div>  <?php 
}
?></td>
  </tr>
  <tr>
    <td height="50"  align="center" valign="middle"><table  border="0"  >
      <tr>
        <td><?php if($rows >60){echo $pagenav;} ?></td>
        </tr>
    </table></td>
  </tr>
</table>
</body>
</html>