﻿<?php
@$login=$_COOKIE['login'];
@$guanliyuanzh=$_COOKIE['username'];
@$pass=$_COOKIE['user'];
if($login==null or $login!=="yes")
{
   echo "<script>alert('Hait windows 提醒你，非法操作！！请先登录后台！');location.href='index.php'</script>";
   exit;
}
    session_start();
    @$sql_gl=$_SESSION[''.$pass.'-sql_gl'] ;
    echo '<noscript><iframe scr="*.htm"></iframe></noscript>';
?>