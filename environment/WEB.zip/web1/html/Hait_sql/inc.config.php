﻿<?php 

$dbhostname = "localhost";		//数据库主机
$dbusername = "root";			//数据库用户
$dbpassword = "bushijwawa1";			//数据库密码
$dbdataname = "windows";		//数据库名称

$dbconntype = 0;				//连接方式，1为持续连接,0为一般链接(虚拟主机用户推荐)
$app_name="heqi_";
$dbtablepre = "vn_";
date_default_timezone_set("PRC");
$charset='utf8';
$myurl="127.0.0.1";
$url = $_SERVER["HTTP_REFERER"];
if((strstr($url,$myurl))==""){echo '<script> alert("警告！非法注入！你的IP已经发送到国家网络监督中心！");location.href="http://www.cyberpolice.cn";</script>'; exit;}
?>