﻿<?php
$conn=mysql_connect("localhost","root","bushijwawa1")or die("数据库连接失败");
$db=mysql_select_db("windows")or die("没有找到库,可能输错了");
mysql_query("set names utf8");
ini_set("date.timezone","PRC");
$myurl="127.0.0.1";
$url = $_SERVER["HTTP_REFERER"];
?>