﻿<?php
error_reporting(0);
require 'config.php';
$id=$_GET["id"];  
require_once'Hait_app/Hait_function.php';
$rows = mysql_num_rows(mysql_query("select * from hait_pinglun  where article_id='$id'",$conn));
$row=$rows+1;
$sql = "select * from hait_article  where id='$id'"; 
$show= mysql_query($sql,$conn); 
$shows = mysql_fetch_array($show);
$pv=$shows['pv'] + 1;
$inssql="update hait_article set pv='$pv' where id='$id'";
  mysql_query($inssql,$conn);
if($shows['huishou']==1 or $shows['shenhe']==2){
   echo '<script>alert("对不起！该信息未审核,或已经被管理员删除！");location.href="Hait_list.php?id='.$shows[channel].'";</script>';
   exit;}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="Hait_images/hait_windows.css" />
<link rel="stylesheet" type="text/css" href="Hait_images/hait_menu.css" />
<style type="text/css">
<!--
body,td,th {
	font-size: 13px;
}
-->
</style></head>
<body>
<div class="show_body">
<table width="96%" align="center">
  <tr>
    <td colspan="2" align="left" valign="middle"><table width="96%" >
      <tr>
        <td width="50%" align="left">
		  <!-- JiaThis Button BEGIN -->
<div id="ckepop">
	<a href="http://www.jiathis.com/share" class="jiathis jiathis_txt" target="_blank"><img src="http://v2.jiathis.com/code/images/btn/v1/jiathis5.gif" border="0" /></a></div>
<script type="text/javascript" src="http://v2.jiathis.com/code/jia.js" charset="utf-8"></script>
<!-- JiaThis Button END --></td>
        <td width="50%" align="right">&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td>
	
<table width="100%" border="0">
      <tr>
        <td height="40" align="center" class="show_title"><?php echo $shows['title'];?></td>
      </tr>
      <tr>
        <td align="center" class="title_down" ><?php echo "文章来源："; 
	      echo $shows['source'];
		  echo "&nbsp;&nbsp;作者：";
		  echo $shows['editor'];
		  echo "&nbsp;&nbsp;浏览次数：";
		  echo $shows['pv'];
		  echo "&nbsp;&nbsp;添加日期：";
		  echo $shows['posttime'];
		  ?></td>
      </tr>
      <tr>
        <td class="show"><?php echo $shows['content'];?></td>
      </tr>
</table>  </td>
  </tr>
  <tr>
    <td>
	
	<table width="470" border="0">
      <tr>
        <td>最新评论：</td>
        <td align="right">共有&nbsp;<?php echo $rows;?>&nbsp;条评论【<a href="hait_app/hait_pinglun.php?id=<?php echo $id;?>">查看所有评论</a>】</td>
      </tr>
      <tr>
	  <!--开始循环--> 
	  <?php
        error_reporting(0);
        require 'config.php';
        $pinglun1 = "select * from hait_pinglun  where article_id='$id' order by id desc limit 0,10";
		$pinglunrows = mysql_num_rows($pinglun1);
        $pinglun2= mysql_query($pinglun1,$conn); 
         while( $pinglun= mysql_fetch_array($pinglun2)){?>
<td width="50%" >
第<?php echo $pinglun['louceng'];?> 楼&nbsp;&nbsp;<span class="pinglun_name"><?php echo $pinglun['name'];?></span></td>
<td  align="right" ><?php echo $pinglun['posttime'];?>发表</td>
</tr><tr>
<td colspan="2">
<?php echo $pinglun['pinglun'];?></td>  </tr>
 <td colspan="2">
<div class="pinglun_down"></div></td>  </tr>

	    		 <?php }?>
	  
	  <!--结束循环--> 
	      </table>
	
	  </td>
  </tr>
  <tr>
  <td> <table width="470" border="0">
    <form action="hait_app/hait_app.php?use=pinglun&id=<?php echo $id;?>&louceng=<?php echo $row;?>" method="post" />
      <tr>
        <td width="100" align="right">网&nbsp;名：</td>
        <td width="147"><input type="text" name="name" size="20"  onkeyup="value=value.replace(/[^\a-\z\A-\Z0-9\u4E00-\u9FA5\,\.\!\，\。\！\?\？\！\《\》\(\)\（\）]/g,'')"/></td>
        <td width="68" align="right">邮&nbsp;箱：</td>
        <td width="140"><input type="text" name="email" size="20"  onkeyup="value=value.replace(/[^\a-\z\A-\Z0-9\u4E00-\u9FA5\,\.\!\，\。\！\?\？\！\《\》\(\)\（\）]/g,'')" /></td>
      </tr>
      <tr>
        <td align="right" valign="top">内&nbsp;容：</td>
        <td colspan="3"><textarea name="pinglun"  style="width:100%; height:100px"  onkeyup="value=value.replace(/[^\a-\z\A-\Z0-9\u4E00-\u9FA5\,\.\!\，\。\！\?\？\！\《\》\(\)\（\）]/g,'')"></textarea></td>
      </tr>
      <tr>
        <td align="right">验证码：</td>
        <td colspan="3"><table border="0">
            <tr>
              <td><input type="text" name="yzm" size="5" /></td>
              <td><img src="hait_app/hait_yzm.php" width="50" height="25" /></td>
            </tr>
          </table></td>
        </tr>
      <tr>
        <td>&nbsp;</td>
        <td colspan="3"><input type="submit"  size="10" value="发表评论" /></td>
        </tr>	</form>
		    </table>	</td>
  </tr>
</table>
</div>
</body>
</html>