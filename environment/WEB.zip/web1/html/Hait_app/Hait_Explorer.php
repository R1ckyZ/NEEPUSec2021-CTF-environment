﻿<?php
if(!empty($_POST['url'])==""){$goto="http://www.baidu.com";}else{$goto=$_POST['url'];}
?><form action="Hait_explorer.php"  method="post" > 
<table width="100%" border="0">
  <tr>
    <td width="100" align="right">地址（URL)：</td>
    <td><input name="url" type="text" style="width:100%;" /></td>
    <td><input type="submit" name="submit" value="跳转"&nbsp; /></td>
  </tr>
  <tr>
    <td colspan="3"><iframe src=<?php echo $goto;?> width=100% height=100% frameborder="0" /></frame>&nbsp;</td>
  </tr>
</table>
</form>