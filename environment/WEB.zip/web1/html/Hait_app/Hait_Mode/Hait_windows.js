{"data":[
	#hait_windows#
	{"id":30,"iconName":"刷新桌面","iconUrl":"img/shortcut/news.png","url":"刷新桌面.html","width":500,"height":300,"resize":false}
]}