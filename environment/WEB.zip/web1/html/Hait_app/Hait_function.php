﻿<?php 
//以下是列表框代码
function Haitlist(){
         error_reporting(0);
         require 'config.php';
         $Haitlist1 = "select * from hait_class  where lmlx<>11 order by id desc";
         $Haitlist2 = mysql_query($Haitlist1, $conn);
         while($haitli=mysql_fetch_array($Haitlist2))
         {echo '<option value='.$haitli[id].'>';
		 echo $haitli['classname'];
		 echo '</option>';}	 
}	

//一下是分页函数
function Page($rows,$page_size,$id){ 
global $page,$select_from,$select_limit,$pagenav; 
$page_count = ceil($rows/$page_size); 
if($page <= 1 || $page == '') $page = 1; 
if($page >= $page_count) $page = $page_count; 
$select_limit = $page_size; 
$select_from = ($page - 1) * $page_size.','; 
$pre_page = ($page == 1)? 1 : $page - 1; 
$next_page= ($page == $page_count)? $page_count : $page + 1 ; 
$pagenav .= "<input name=button type=button class=menu onclick=window.location.href='?id=$id&page=1' 
class=menu value=首页> "; 
$pagenav .= "<input name=button type=button class=menu onclick=window.location.href='?id=$id&page=$pre_page' 
class=menu value=上一页>"; 
$pagenav .= "<input name=button type=button class=menu onclick=window.location.href='?id=$id&page=$next_page' 
class=menu value=下一页>"; 
$pagenav .= "<input name=button type=button class=menu onclick=window.location.href='?id=$id&page=$page_count' 
class=menu value=尾页>"; 
$pagenav.="<select name='topage' size='1' style='border:1px solid #FF6600; font-family: Arial, Helvetica, sans-serif;height:20px; margin:5px 5px 2px 2px;'onchange='window.location=\"?id=$id&page=\"+this.value'>\n";
for($i=1;$i<=$page_count;$i++){ 
if($i==$page) $pagenav.="<option value='$i' selected>第&nbsp;$i&nbsp;页</option>\n"; 
else $pagenav.="<option value='$i'>第&nbsp;$i&nbsp;页</option>\n"; 
} 
}
//以下是截取字符串函数
function GBsubstr($string, $start, $length) {
    if(strlen($string)>$length){
     $str=null;
     $len=$start+$length;
     for($i=$start;$i<$len;$i++){
    if(ord(substr($string,$i,1))>0xa0){
     $str.=substr($string,$i,3); //如果使用的编码是UTF8的话处为3，且下面再加一个$i++;
     $i++;
	 $i++;
    }else{
     $str.=substr($string,$i,1);
     }
    }
   return $str.'...';
    }else{
   return $string;
   }
}
//以下是楼层函数
function Hait_rows($lou){
         error_reporting(0);
         require 'config.php';
		 $rows = mysql_num_rows(mysql_query("select * from hait_pinglun  where article_id='$lou'",$conn));
         echo $rows+1;
}

?>