﻿<?php
error_reporting(0);
require '../config.php';
$id=$_GET["id"]; 
$page= $_GET["page"];  
require_once'../Hait_app/Hait_function.php';
$rows = mysql_num_rows(mysql_query("select * from hait_pinglun  where article_id='$id'",$conn));
$row=$rows+1;
Page($rows,20,$id); 
$sql = "select * from hait_article  where id='$id' "; 
$show= mysql_query($sql,$conn); 
$shows = mysql_fetch_array($show);
if($shows['huishou']==1 or $shows['shenhe']==2){
   echo '<script>alert("对不起！该信息未审核,或已经被管理员删除！");location.href="Hait_list.php?id='.$shows[channel].'";</script>';
   exit;}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Hait windows 后台管理</title>
<link rel="stylesheet" type="text/css" href="../Hait_images/hait_windows.css" />
<link rel="stylesheet" type="text/css" href="../Hait_images/hait_menu.css" />
<style type="text/css">
<!--
body,td,th {
	font-size: 13px;
}
-->
</style></head>
<body>
<table width="70%" align="center" class="pinglun_body">
  <tr>
    <td colspan="2" align="left" valign="middle"><table width="96%" >
      <tr>
        <td width="50%" align="left">
		  <!-- JiaThis Button BEGIN -->
<div id="ckepop">
	<a href="http://www.jiathis.com/share" class="jiathis jiathis_txt" target="_blank"><img src="http://v2.jiathis.com/code/images/btn/v1/jiathis5.gif" border="0" /></a></div>
<script type="text/javascript" src="http://v2.jiathis.com/code/jia.js" charset="utf-8"></script>
<!-- JiaThis Button END --></td>
        <td width="50%" align="right">&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td>
	
<table width="100%" border="0">
      <tr>
        <td align="left" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;关于&nbsp;“<span class="pinglun_title"><a href="../hait_show.php?id=<?php echo $_GET["id"];?>"><?php echo $shows['title'];?></a></span>&nbsp;”&nbsp;的所有评论！</td>
      </tr>
</table>  </td>
  </tr>
  <tr>
    <td>
	
	<table width="100%" border="0">
      <tr>
        <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;最新评论：</td>
        <td align="right">共有&nbsp;<?php echo $rows;?>&nbsp;条评论&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
      </tr>
      <tr>
	  <!--开始循环--> 
	  <?php
        error_reporting(0);
        require '../config.php';
        $pinglun1 = "select * from hait_pinglun  where article_id='$id' order by id desc  limit $select_from $select_limit";
		$pinglunrows = mysql_num_rows($pinglun1);
        $pinglun2= mysql_query($pinglun1,$conn); 
         while( $pinglun= mysql_fetch_array($pinglun2)){?>
<td >
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;第<?php echo $pinglun['louceng'];?> 楼&nbsp;&nbsp;&nbsp;<span class="pinglun_name"><?php echo $pinglun['name'];?>&nbsp;&nbsp;&nbsp;Email:<?php echo $pinglun['email'];?></span></td>
<td  align="right" ><?php echo $pinglun['posttime'];?>发表&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
</tr><tr>
<td colspan="2">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $pinglun['pinglun'];?></td>  </tr>
 <td colspan="2">
<div class="pinglun_down"></div></td>  </tr>

	    		 <?php }?>
	  
	  <!--结束循环--> <tr>
        <td align="center" colspan="2" ><?php if($rows >1){echo $pagenav;} ?></td>
      </tr>
        </table>
	
	  </td>
  </tr>
  <tr>
  <td> <table width="470" border="0">
    <form action="hait_app.php?use=pinglun&id=<?php echo $id;?>&louceng=<?php echo $row;?>" method="post" />
      <tr>
        <td width="100" align="right">网&nbsp;名：</td>
        <td width="147"><input type="text" name="name" size="20"  onkeyup="value=value.replace(/[^\a-\z\A-\Z0-9\u4E00-\u9FA5\,\.\!\，\。\！\?\？\！\《\》\(\)\（\）]/g,'')" /></td>
        <td width="68" align="right">邮&nbsp;箱：</td>
        <td width="140"><input type="text" name="email" size="20"onkeyup="value=value.replace(/[^\a-\z\A-\Z0-9\u4E00-\u9FA5\,\.\!\，\。\！\?\？\！\《\》\(\)\（\）]/g,'')"  /></td>
      </tr>
      <tr>
        <td align="right" valign="top">内&nbsp;容：</td>
        <td colspan="3"><textarea name="pinglun"  style="width:100%; height:100px" onkeyup="value=value.replace(/[^\a-\z\A-\Z0-9\u4E00-\u9FA5\,\.\!\，\。\！\?\？\！\《\》\(\)\（\）]/g,'')" ></textarea></td>
      </tr>
      <tr>
        <td align="right">验证码：</td>
        <td colspan="3"><table border="0">
          <tr>
            <td><input type="text" name="yzm" size="5" /></td>
            <td><img src="hait_yzm.php" width="50" height="25" /></td>
          </tr>
        </table></td>
        </tr>
      <tr>
        <td>&nbsp;</td>
        <td colspan="3"><input type="submit"  size="10" value="发表评论" /></td>
        </tr>	</form>
		    </table>	</td>
  </tr>
</table>

</body>
</html>