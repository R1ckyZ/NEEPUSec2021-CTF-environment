﻿<?php
require("../config.php");
if((strstr($url,$myurl))==""){echo '<script> alert("警告！非法注入！你的IP已经发送到国家网络监督中心！");location.href="http://www.cyberpolice.cn";</script>';exit;}
$appname=$_GET['use'];
$use_id=$_GET['id'];
SWITCH($appname){
case "pinglun";
@$yanzhen=$_COOKIE['pinglun'];
if($yanzhen==$use_id){echo '<script> alert("提示！您已经评论过啦！！！");location.href="../hait_show.php?id='.$_GET["id"].'";</script>';exit;}
$name=$_POST['name'];
$email=$_POST['email'];
$pinglun=$_POST['pinglun'];
@$louceng=$_GET['louceng'];
$posttime=date("Y-m-d H:i:s");
//以下是验证码信息
session_start();
@$yzm=$_POST['yzm'];
if($yzm<>$_SESSION["code"]){ echo "<script>alert('提示！验证码输入错误,请重新输入！');history.back();</script>";exit;}
//验证码结束
if($name=="" or $pinglun=="" or $email==""){  echo "<script>alert('提示！网名，邮件，评论内容不能为空,请重新输入！');history.back();</script>";}
$inssql="insert into hait_pinglun (name,email,pinglun,posttime,article_id,louceng) values ('$name','$email','$pinglun','$posttime','$use_id','$louceng')";
$ok=mysql_query($inssql,$conn);
if($ok){
setcookie("pinglun",$use_id,time()+30000,'/');
echo '<script> alert("提示！评论添加成功！");location.href="../hait_show.php?id='.$_GET["id"].'";</script>';}
break;
}
?>
