<?php
session_start();
function random($len)
{
$srcstr="ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
mt_srand();//
$strs="";
for($i=0;$i <$len;$i++){
$strs.=$srcstr[mt_rand(0,35)];
}
return strtoupper($strs);
}
$str=random(4); //��֤��λ��
$width = 50; //ͼƬ����
$height = 25; //ͼƬ�߶�
@header("Content-Type:image/png;");
$_SESSION["code"] = $str;
$im=imagecreate($width,$height);
//ͼƬ��ɫ
$back=imagecolorallocate($im,0xFF,0xFF,0xFF);
//??
$pix=imagecolorallocate($im,187,230,247);
//?
$font=imagecolorallocate($im,41,163,238);
//???
mt_srand();
for($i=0;$i <1000;$i++)
{
imagesetpixel($im,mt_rand(0,$width),mt_rand(0,$height),$pix);
}
imagestring($im, 5, 7, 5,$str, $font);
imagerectangle($im,0,0,$width-1,$height-1,$font);
imagepng($im);
imagedestroy($im);
$_SESSION["code"] = $str;
?>