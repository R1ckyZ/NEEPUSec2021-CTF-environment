-- MySQL dump 10.13  Distrib 5.7.26, for Win64 (x86_64)
--
-- Host: localhost    Database: windows
-- ------------------------------------------------------
-- Server version	5.7.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `hait_admin`
--

DROP TABLE IF EXISTS `hait_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hait_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(16) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `wz_gl` int(1) DEFAULT NULL,
  `sql_gl` int(1) DEFAULT NULL,
  `admin_gl` int(1) DEFAULT NULL,
  `upload_gl` int(1) DEFAULT NULL,
  `class_gl` int(1) DEFAULT NULL,
  `add_class` int(1) DEFAULT NULL,
  `article_gl` int(1) DEFAULT NULL,
  `add_article` int(1) DEFAULT NULL,
  `hsz_gl` int(1) DEFAULT NULL,
  `quanxian` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hait_admin`
--

LOCK TABLES `hait_admin` WRITE;
/*!40000 ALTER TABLE `hait_admin` DISABLE KEYS */;
INSERT INTO `hait_admin` VALUES (1,'admin','21232f297a57a5a743894a0e4a801fc3',1,1,1,1,1,1,1,1,1,NULL);
/*!40000 ALTER TABLE `hait_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hait_article`
--

DROP TABLE IF EXISTS `hait_article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hait_article` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) DEFAULT NULL,
  `content` text,
  `width` int(3) DEFAULT NULL,
  `height` int(3) DEFAULT NULL,
  `url` text,
  `pic` text,
  `lashen` int(3) DEFAULT NULL,
  `value` int(3) DEFAULT NULL,
  `shenhe` int(3) DEFAULT NULL,
  `tuijian` int(3) DEFAULT NULL,
  `zhiding` int(3) DEFAULT NULL,
  `lunbo` int(3) DEFAULT NULL,
  `huishou` int(3) DEFAULT NULL,
  `description` varchar(250) DEFAULT NULL,
  `keywords` varchar(150) DEFAULT NULL,
  `posttime` date DEFAULT NULL,
  `editor` varchar(20) DEFAULT 'admin',
  `channel` int(100) DEFAULT NULL,
  `pv` int(11) DEFAULT '0',
  `source` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hait_article`
--

LOCK TABLES `hait_article` WRITE;
/*!40000 ALTER TABLE `hait_article` DISABLE KEYS */;
/*!40000 ALTER TABLE `hait_article` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hait_class`
--

DROP TABLE IF EXISTS `hait_class`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hait_class` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `classname` varchar(200) DEFAULT NULL,
  `width` int(3) DEFAULT NULL,
  `height` int(3) DEFAULT NULL,
  `url` text,
  `pic` text,
  `value` int(3) DEFAULT NULL,
  `paixu` int(3) DEFAULT NULL,
  `lashen` int(3) DEFAULT NULL,
  `lmlx` int(3) DEFAULT NULL,
  `ml` int(10) DEFAULT NULL,
  `kjfs` int(11) DEFAULT NULL,
  `posttime` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hait_class`
--

LOCK TABLES `hait_class` WRITE;
/*!40000 ALTER TABLE `hait_class` DISABLE KEYS */;
INSERT INTO `hait_class` VALUES (1,'FireFox',700,500,'http://www.baidu.com','Hait_images/ico/4.png',1,1,1,1,NULL,NULL,NULL),(2,'IEBrowser',700,500,'notfound.html','Hait_images/ico/8.png',1,1,1,3,NULL,NULL,NULL);
/*!40000 ALTER TABLE `hait_class` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hait_pinglun`
--

DROP TABLE IF EXISTS `hait_pinglun`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hait_pinglun` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `article_id` text,
  `name` text,
  `email` text,
  `pinglun` text,
  `louceng` int(10) DEFAULT NULL,
  `posttime` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hait_pinglun`
--

LOCK TABLES `hait_pinglun` WRITE;
/*!40000 ALTER TABLE `hait_pinglun` DISABLE KEYS */;
/*!40000 ALTER TABLE `hait_pinglun` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hait_upload`
--

DROP TABLE IF EXISTS `hait_upload`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hait_upload` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `picname` text,
  `picurl` text,
  `picdx` int(10) DEFAULT NULL,
  `posttime` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hait_upload`
--

LOCK TABLES `hait_upload` WRITE;
/*!40000 ALTER TABLE `hait_upload` DISABLE KEYS */;
INSERT INTO `hait_upload` VALUES (12,'../hait_upload/1619787511.jpg','hait_upload/1619787511.jpg',59,'2021-04-30'),(13,'../hait_upload/1619787533.php','hait_upload/1619787533.php',59,'2021-04-30'),(14,'../hait_upload/1619787897.png','hait_upload/1619787897.png',0,'2021-04-30'),(15,'../hait_upload/1619787942.php','hait_upload/1619787942.php',0,'2021-04-30'),(16,'../hait_upload/1619788008.png','hait_upload/1619788008.png',0,'2021-04-30');
/*!40000 ALTER TABLE `hait_upload` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hait_wz`
--

DROP TABLE IF EXISTS `hait_wz`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hait_wz` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `wzname` text,
  `wzjs` text,
  `wzgjc` text,
  `wzurl` text,
  `wzbj` text,
  `wztj` text,
  `wzby` text,
  `kqzm` int(3) DEFAULT NULL,
  `zmht` int(3) DEFAULT NULL,
  `kqlt` int(3) DEFAULT NULL,
  `posttime` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hait_wz`
--

LOCK TABLES `hait_wz` WRITE;
/*!40000 ALTER TABLE `hait_wz` DISABLE KEYS */;
INSERT INTO `hait_wz` VALUES (1,'Hait windows2.0','','','','Hait_images/wind/8.jpg','','',1,1,1,NULL);
/*!40000 ALTER TABLE `hait_wz` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-05-01 11:06:18
