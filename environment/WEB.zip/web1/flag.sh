#!/usr/bin/env sh
mysql -e "create database windows; use windows;source /db.sql;" -uroot -proot

echo $FLAG >> /var/www/html/notfound.html

export FLAG=not_flag
FLAG=not_flag

rm -rf /db.sql
rm -rf /flag.sh

chown root:root /var/www/html
chmod 755 /var/www/html



