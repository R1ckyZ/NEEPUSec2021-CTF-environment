<?php
$secret = 'Neepu is the best! :)';