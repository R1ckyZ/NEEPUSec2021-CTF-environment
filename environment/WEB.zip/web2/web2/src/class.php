<?php
class wordlist{
    public $words = array("1"=>"Oh Oh Oh wait?", "2"=>"This may be a breakthrough!", "3"=>"Maybe Robots will tell you something...", "4"=>"Everyone who tried to get the flag failed", "5"=>"Is there really a flag here?", "6"=>"web check in check in ~", "7"=>"Make a small sacrifice for the great nothingness", "8"=>"The ignorant is fearless", "9"=>"details make a difference");
    public $model = 1;
    public $file;
    public $content;

    public function __construct($file, $content) {
        $this->file = $file;
        $this->content = $content;
    }

    /**
     * @read check wordlist
     */
    public function read()
    {
        return file_get_contents($this->file);
    }

    /**
     * @write upload wordlist
     */
    public function write()
    {
        return file_put_contents($this->file, $this->content);
    }

    /**
     * @destruct output wordlist
     */
    public function __destruct()
    {
        if($this->model) {
            echo $this->words{rand(1,9)};
        }
        else {
            die("wrong model, please check!");
        }
    }
}

