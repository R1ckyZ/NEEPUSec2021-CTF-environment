<?php
/*
# -*- coding: utf-8 -*-
# @Author: Ricky

*/

error_reporting(0);
include('class.php');
$word = 'O:8:"wordlist":2:{s:5:"words";a:9:{i:1;s:14:"Oh Oh Oh wait?";i:2;s:27:"This may be a breakthrough!";i:3;s:39:"Maybe Robots will tell you something...";i:4;s:41:"Everyone who tried to get the flag failed";i:5;s:28:"Is there really a flag here?";i:6;s:23:"web check in check in ~";i:7;s:48:"Make a small sacrifice for the great nothingness";i:8;s:24:"The ignorant is fearless";i:9;s:25:"details make a difference";}s:5:"model";i:1;}';
?>
<!DOCTYPE html>
<html>
	<head>
		<title>LOVE DEATH AND ROBOTS</title>
		<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
		<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
		<!-- web-font -->
		<link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
		<link href='http://fonts.googleapis.com/css?family=Playball' rel='stylesheet' type='text/css'>
		<!-- web-font -->
		<!-- js -->
		<script src="js/jquery.min.js"></script>
		<script src="js/modernizr.custom.js"></script>
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
		<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
		<!-- js -->
		<script src="js/modernizr.custom.js"></script>
		<!-- start-smoth-scrolling -->
		<script type="text/javascript" src="js/move-top.js"></script>
		<script type="text/javascript" src="js/easing.js"></script>
		<script type="text/javascript">
			jQuery(document).ready(function($) {
				$(".scroll").click(function(event){		
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
				});
			});
		</script>
		<!-- start-smoth-scrolling -->
	</head>
	<body>
		<!-- header -->
		<div class="header">
			<div class="head-bg">
				<!-- container -->
				<div class="container">
					<div class="head-logo">
						<a href="javascript:alert('Awesome! you found the surprise, but what does it have to do with the flag?');"><img src="images/logo1.png" alt="" /></a>
					</div>
					<div class="clearfix"> </div>
				</div>
				<!-- //container -->
			</div>
			<!-- container -->
			<div class="container">
				<!-- banner Slider starts Here -->
					<script src="js/responsiveslides.min.js"></script>
					 <script>
						// You can also use "$(window).load(function() {"
						$(function () {
						  // Slideshow 4
						  $("#slider3").responsiveSlides({
							auto: true,
							pager: false,
							nav: false,
							speed: 500,
							namespace: "callbacks",
							before: function () {
							  $('.events').append("<li>before event fired.</li>");
							},
							after: function () {
							  $('.events').append("<li>after event fired.</li>");
							}
						  });
					
						});
					  </script>
					<!--//End-slider-script -->
					<div  id="top" class="callbacks_container">
						<ul class="rslides" id="slider3">
							<li>
								<div class="head-info">
									<h1>LOVE DEATH AND ROBOTS<span><font color="#00FFFF">What people see is what they want to see</font></span></h1>
                                    <p><?php unserialize($word);?></p>
								</div>
							</li>
							<li>
								<div class="head-info">
									<h1>Killing and saving, good and evil<span><font color="#00FFFF">They played to death by themselves</font></span></h1>
                                    <p><?php unserialize($word);?></p>
								</div>
							</li>
							<li>
								<div class="head-info">
									<h1>Beauty and danger coexist<span><font color="#00FFFF">Never find flag unless you make a backup</font></span></h1>
									<p><?php unserialize($word);?></p>
								</div>
							</li>
						</ul>
					</div>

			</div>
			<!-- container -->
		</div>
		<!-- //header -->
		<!-- banner-grids -->
		<div class="banner-grids">
			<!-- container -->
			<div class="container">
				<div class="banner-grid-info">
					<h3>LOVE + DEATH & ROBOTS</h3>
					<p>Technology, romance, beauty, deception, truth, horror</p>
				</div>
				<div class="top-grids">
					<div class="top-grid">
						<img src="images/6.jpg" alt="" />
						<div class="top-grid-info">
							<h3>Thinker</h3>
							<p>Who cares about those flags? Calm down with me and enjoy this moment.</p>
						</div>
					</div>
					<div class="top-grid">
						<img src="images/3.jpg" alt="" />
						<div class="top-grid-info">
							<h3>Fighter</h3>
							<p>The machine also has a soul, which comes from the tacit understanding between the operator and the machine.</p>
						</div>
					</div>
					<div class="top-grid">
						<img src="images/2.jpg" alt="" />
						<div class="top-grid-info">
							<h3>Human</h3>
							<p>Maybe you should think about it for a long time.</p>
						</div>
					</div>
					<div class="top-grid">
						<img src="images/4.jpg" alt="" />
						<div class="top-grid-info">
							<h3>Alien</h3>
							<p>The flag is really obvious, you need to believe in yourself.</p>
						</div>
					</div>
					<div class="clearfix"> </div>
				</div>
			</div>
			<!-- //container -->
		</div>
		<!-- //banner-grids -->
	</body>
</html>