#!/usr/bin/env sh
echo '<?php $n22pvflll4g = "'$FLAG'";echo $n22pvflll4g;?>' > /var/www/html/n33pvfl4g.php

export FLAG=not_flag
FLAG=not_flag

rm -rf /flag.sh
