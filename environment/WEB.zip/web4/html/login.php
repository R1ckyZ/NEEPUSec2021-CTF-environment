<!doctype html>
<html lang="zh">
<head>
<meta charset="UTF-8">
<title>登录</title>
<link rel="stylesheet" type="text/css" href="css/styles.css">
</head>
<body>
<div class="htmleaf-container">
	<div class="wrapper">
		<div class="container">
			<h1>Welcome</h1>
			
			<form class="form" method="post" action="login.php">
				<input type="text" placeholder="username" name="username">
				
				<button type="submit" id="login-button">Login</button>
			</form>
		</div>
	</div>
</div>

<script src="js/jquery-2.1.1.min.js" type="text/javascript"></script>

<div style="text-align:center;margin:50px 0; font:normal 14px/24px 'MicroSoft YaHei';color:#000000">
</div>
</body>
</html>


<?php
error_reporting(0);
function waf($str)
{
    $str=str_ireplace("union","waf",$str);
    $str=str_ireplace("select","waf",$str);
    $str=str_ireplace(" ","waf",$str);
    $str=str_ireplace("union","waf",$str);
    $str=str_ireplace("and","waf",$str);
    $str=str_ireplace("or","waf",$str);
    $str=str_ireplace("if","waf",$str);
    $str=str_ireplace("insert","waf",$str);
    $str=str_ireplace("delete","waf",$str);
    $str=str_ireplace("update","waf",$str);
    $str=str_ireplace("||","waf",$str);
    $str=str_ireplace("#","waf",$str);
    $str=str_ireplace("--","waf",$str);
    $str=str_ireplace("benchmark","waf",$str);
    $str=str_ireplace("case get_lock","waf",$str);
    $str=str_ireplace("sleep","waf",$str);
    return $str;
}

$user = waf($_POST['username']);
$num = preg_match('/waf/',$user);
if($user!="")																			//用户名存在的话
{
    if($num!=0)
    {
        echo "<script>alert('用户名包含敏感词');location.href='login.php';</script>";
    }
    $coon = mysqli_connect("localhost","root","root");
    mysqli_select_db($coon,"neepuctf");
    $sql = "select * from user where username = '$user'";							    //查询用户表中该用户
    $result = mysqli_query($coon,$sql);													//执行查询语句
    $rowcount = mysqli_num_rows($result);												//返回查询结果行数
    if($rowcount<1){
        echo "<script>alert('该用户不存在，请重新登陆');location.href='login.php';</script>";
    }
    else
    {
            session_start();               												//启用session
            $_SESSION["username"]=  $_POST['username'];									//储存登陆用户名
			$_SESSION['num'] = 0;
            echo "<script>alert('登录成功!');location.href='index.php';</script>";		//跳转到留言板
    }

    mysqli_close($coon);    															//关闭连接
} 
?>










