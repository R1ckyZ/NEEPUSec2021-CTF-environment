<?php
// create object
if ($_SESSION['num'] >= 5) {
	include('smarty/Smarty.class.php');
	$smarty = new Smarty;
	$name = $_SESSION["username"];
	$smarty->display('string:恭喜 '.$name.' 获得了胜利');
}