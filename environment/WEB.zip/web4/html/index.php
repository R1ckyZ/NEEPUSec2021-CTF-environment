<?php

error_reporting(0);
session_start();
if(!isset($_SESSION["username"])){
	$url = "http://" . $_SERVER['HTTP_HOST'] . "/login.php";
    header("Location:" . $url);
	exit();
}

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>游戏中心</title>
    <link rel="stylesheet" type="text/css" href="css/identify.css"/>
    <link rel="stylesheet" type="text/css" href="css/layout.css"/>
    <link rel="stylesheet" type="text/css" href="css/account.css"/>
    <link rel="stylesheet" type="text/css" href="css/style.css"/>
    <link rel="stylesheet" type="text/css" href="css/control_index.css"/>
    <script type="text/javascript" src="js/jquery-1.7.2.min.js"></script>
    <script type="text/javascript" src="js/layer/layer.js"></script>
    <script type="text/javascript" src="js/haidao.offcial.general.js"></script>
    <script type="text/javascript" src="js/select.js"></script>
</head>

<body>
<div class="view-topbar">
    <div class="topbar-console">
        <div class="tobar-head fl">
            <a href="#" class="topbar-logo fl">
                <span><img src="Images/logo.png" width="20" height="20"/></span>
            </a>
            <a href="index.php" class="topbar-home-link topbar-btn text-center fl"><span>游戏大厅</span></a>
        </div>
    </div>
    <div class="topbar-info">
    </div>
</div>
<div class="view-body">
    <div class="view-sidebar">
        <div class="sidebar-content">
            <div class="sidebar-nav">
                <div class="sidebar-title">
                    <a href="#">
                        <span class="icon"><b class="fl icon-arrow-down"></b></span>
                        <span class="text-normal">我的游戏</span>
                    </a>
                </div>
                <ul class="sidebar-trans">
                    <li>
                        <a href="#">
                            <b class="sidebar-icon"><img src="Images/icon_author.png" width="16" height="16"/></b>
                            <span class="text-normal">掷硬币</span>
                        </a>
                </ul>
            </div>
        </div>
    </div>
</div>
<?php
$arr = array(3436, 6275, 7481, 6283, 8996, 4951, 6691, 1706, 5912, 5160, 1039, 5281, 1080, 9120, 1630, 6405, 6200, 2272, 3235, 8741, 6317, 1161, 5463, 2227, 8930, 3259, 3679, 2812, 5324, 8160, 6710, 8098, 5251, 2085, 6740, 6798, 3839, 5513, 7080, 5085, 9397, 9329, 6792, 5053, 3195, 8541, 3242, 2603, 1653, 3580);
$newarr = array_rand($arr, 1);
?>
<div class="view-product background-color">
    <div class="padding-big background-color">
        <br/><br/><br/>猜硬币正反，连续猜对五次胜利<br/><br/>你已经猜对了<?php echo($_SESSION['num']); ?>次<br/><br/>

        <form method="post" action="./index.php">
            <p>
                正: <input type="radio" name="guess" checked="yes" value="on"/><br/>
                反: <input type="radio" name="guess" value="off"/>
            </p><br/>

            <p>
                <img id="captcha_img" border="1" src="./pic/<?php echo $arr[$newarr]; ?>.jpg" width=100
                     height=30>
            </p>
            <p>请输入图片中的内容：<input type="text" name="authcode" value=""/></p><br/>
            <p><input type="submit" value="提交"
                      style="background-color: #7ED321;width: 76px;height: 25px;color: #FFFFFF"></p>
        </form>
        <br/>
        <?php if ($_SESSION['num'] >= 5) {
            $file = $_GET['file'];
            if ($file == "") {
                $url = "http://" . $_SERVER['HTTP_HOST'] . "/index.php?file=rander.php";
                header("Location:" . $url);
            }
            if(!preg_match('/^\/|\.\//', $filename)) {
                include($file);
            }
        } ?>
    </div>
</div>

<script>
    $(".sidebar-title").live('click', function () {
        if ($(this).parent(".sidebar-nav").hasClass("sidebar-nav-fold")) {
            $(this).next().slideDown(200);
            $(this).parent(".sidebar-nav").removeClass("sidebar-nav-fold");
        } else {
            $(this).next().slideUp(200);
            $(this).parent(".sidebar-nav").addClass("sidebar-nav-fold");
        }
    });
</script>
</body>

<?php
if (!isset($_SESSION['num'])) {
    $_SESSION['num'] = 0;
}
if (!isset($_SESSION['authcode'])) {
    $_SESSION['authcode'] = $arr[$newarr];
}
if (isset($_REQUEST['authcode'])) {
    if (strtolower($_REQUEST['authcode']) == $_SESSION['authcode']) {
        $answer = substr(rand(), 3, 1);
        if ($answer < 5) {
            $answer = "on";
        } else {
            $answer = "off";
        }
        if ($answer == $_POST['guess']) {
            $_SESSION['num']++;
        } else {
            $_SESSION['num'] = 0;
        }
    } else {
        echo "<script>alert('验证码错误');</script>";
    }
    $_SESSION['authcode'] = $arr[$newarr];
}

?>

</html>
