<?php
/* Smarty version 3.1.38, created on 2021-04-21 22:29:57
  from 'D:\phpstudy_pro\WWW\src\templates\index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.38',
  'unifunc' => 'content_608036e51d7784_95670079',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '604db300b0cb1d5c4512119038cc6a80ba2a4e0f' => 
    array (
      0 => 'D:\\phpstudy_pro\\WWW\\src\\templates\\index.tpl',
      1 => 1619015385,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_608036e51d7784_95670079 (Smarty_Internal_Template $_smarty_tpl) {
?><html>
<head>
<title>Info</title>
</head>
<body>

<pre>
User Information:

Name: <?php echo $_smarty_tpl->tpl_vars['name']->value;?>

Address: <?php echo $_smarty_tpl->tpl_vars['address']->value;?>

</pre>

</body>
</html><?php }
}
