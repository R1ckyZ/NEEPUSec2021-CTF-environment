<?php
/* Smarty version 3.1.38, created on 2021-04-22 13:37:45
  from '22c17aec8051b44d76ef49dd621dc9834ae3f2aa' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.38',
  'unifunc' => 'content_60810ba9541ee2_12089102',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60810ba9541ee2_12089102 (Smarty_Internal_Template $_smarty_tpl) {
?>恭喜<?php echo Smarty::SMARTY_VERSION;?>
 获得了胜利<?php }
}
