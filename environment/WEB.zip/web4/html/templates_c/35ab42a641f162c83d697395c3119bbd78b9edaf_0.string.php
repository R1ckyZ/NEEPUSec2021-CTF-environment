<?php
/* Smarty version 3.1.38, created on 2021-04-23 11:19:55
  from '35ab42a641f162c83d697395c3119bbd78b9edaf' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.38',
  'unifunc' => 'content_60823cdbed9629_33260672',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60823cdbed9629_33260672 (Smarty_Internal_Template $_smarty_tpl) {
?>恭喜 <?php ob_start();
echo shell_exec("whoami");
$_prefixVariable1 = ob_get_clean();
echo $_prefixVariable1;?>
'='0 获得了胜利<?php }
}
