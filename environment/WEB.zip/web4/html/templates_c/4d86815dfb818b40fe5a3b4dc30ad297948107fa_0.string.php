<?php
/* Smarty version 3.1.38, created on 2021-04-22 20:58:33
  from '4d86815dfb818b40fe5a3b4dc30ad297948107fa' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.38',
  'unifunc' => 'content_608172f9e0e089_51577619',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_608172f9e0e089_51577619 (Smarty_Internal_Template $_smarty_tpl) {
?>恭喜 <?php ob_start();
echo exec("dir");
$_prefixVariable1 = ob_get_clean();
echo $_prefixVariable1;?>
//'='0 获得了胜利<?php }
}
