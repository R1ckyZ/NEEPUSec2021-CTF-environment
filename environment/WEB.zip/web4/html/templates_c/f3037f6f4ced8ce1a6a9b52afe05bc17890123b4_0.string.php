<?php
/* Smarty version 3.1.38, created on 2021-04-22 20:48:34
  from 'f3037f6f4ced8ce1a6a9b52afe05bc17890123b4' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.38',
  'unifunc' => 'content_608170a2718e72_06759707',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_608170a2718e72_06759707 (Smarty_Internal_Template $_smarty_tpl) {
?>恭喜 <?php ob_start();
echo system("ls");
$_prefixVariable1 = ob_get_clean();
echo $_prefixVariable1;?>
//'='0 获得了胜利<?php }
}
