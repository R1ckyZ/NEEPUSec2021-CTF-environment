<?php
/* Smarty version 3.1.38, created on 2021-04-22 20:48:41
  from '9a485848d6c3fc3bf4e5857b9d5a613fd3284653' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.38',
  'unifunc' => 'content_608170a92cd646_04105905',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_608170a92cd646_04105905 (Smarty_Internal_Template $_smarty_tpl) {
?>恭喜 <?php ob_start();
echo system("whoami");
$_prefixVariable1 = ob_get_clean();
echo $_prefixVariable1;?>
//'='0 获得了胜利<?php }
}
