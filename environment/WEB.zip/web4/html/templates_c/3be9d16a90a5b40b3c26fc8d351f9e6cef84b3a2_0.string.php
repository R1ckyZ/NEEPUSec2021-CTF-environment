<?php
/* Smarty version 3.1.38, created on 2021-04-22 20:56:12
  from '3be9d16a90a5b40b3c26fc8d351f9e6cef84b3a2' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.38',
  'unifunc' => 'content_6081726c94aca6_07844315',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6081726c94aca6_07844315 (Smarty_Internal_Template $_smarty_tpl) {
?>恭喜 <?php ob_start();
echo var_dump(1);
$_prefixVariable1 = ob_get_clean();
echo $_prefixVariable1;?>
//'='0 获得了胜利<?php }
}
