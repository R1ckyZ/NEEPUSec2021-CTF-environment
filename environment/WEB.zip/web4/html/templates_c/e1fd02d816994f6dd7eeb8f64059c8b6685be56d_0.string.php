<?php
/* Smarty version 3.1.38, created on 2021-04-22 20:34:21
  from 'e1fd02d816994f6dd7eeb8f64059c8b6685be56d' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.38',
  'unifunc' => 'content_60816d4d01a608_76231610',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60816d4d01a608_76231610 (Smarty_Internal_Template $_smarty_tpl) {
?>恭喜 <?php echo Smarty::SMARTY_VERSION;?>
//'='0 获得了胜利<?php }
}
