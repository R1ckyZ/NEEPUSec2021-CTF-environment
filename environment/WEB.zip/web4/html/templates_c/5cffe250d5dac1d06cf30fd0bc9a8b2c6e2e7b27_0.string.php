<?php
/* Smarty version 3.1.38, created on 2021-04-22 20:56:52
  from '5cffe250d5dac1d06cf30fd0bc9a8b2c6e2e7b27' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.38',
  'unifunc' => 'content_60817294b90cd2_46652574',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60817294b90cd2_46652574 (Smarty_Internal_Template $_smarty_tpl) {
?>恭喜 <?php ob_start();
echo var_dump(getcwd());
$_prefixVariable1 = ob_get_clean();
echo $_prefixVariable1;?>
//'='0 获得了胜利<?php }
}
