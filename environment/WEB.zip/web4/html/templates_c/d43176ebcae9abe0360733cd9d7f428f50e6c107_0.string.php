<?php
/* Smarty version 3.1.38, created on 2021-04-22 13:47:20
  from 'd43176ebcae9abe0360733cd9d7f428f50e6c107' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.38',
  'unifunc' => 'content_60810de842c7d5_83821226',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60810de842c7d5_83821226 (Smarty_Internal_Template $_smarty_tpl) {
?>恭喜 2 获得了胜利<?php }
}
