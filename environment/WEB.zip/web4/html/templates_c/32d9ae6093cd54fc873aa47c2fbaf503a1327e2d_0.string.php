<?php
/* Smarty version 3.1.38, created on 2021-04-23 11:19:24
  from '32d9ae6093cd54fc873aa47c2fbaf503a1327e2d' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.38',
  'unifunc' => 'content_60823cbc6db8a0_89262122',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60823cbc6db8a0_89262122 (Smarty_Internal_Template $_smarty_tpl) {
?>恭喜 <?php ob_start();
echo exec("whoami");
$_prefixVariable1 = ob_get_clean();
echo $_prefixVariable1;?>
'='0 获得了胜利<?php }
}
