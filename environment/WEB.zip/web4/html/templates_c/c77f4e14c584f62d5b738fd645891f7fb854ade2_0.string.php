<?php
/* Smarty version 3.1.38, created on 2021-04-23 11:15:14
  from 'c77f4e14c584f62d5b738fd645891f7fb854ade2' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.38',
  'unifunc' => 'content_60823bc29ff845_06131924',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60823bc29ff845_06131924 (Smarty_Internal_Template $_smarty_tpl) {
?>恭喜 <?php ob_start();
echo assert(phpinfo());
$_prefixVariable1 = ob_get_clean();
echo $_prefixVariable1;?>
'='0 获得了胜利<?php }
}
