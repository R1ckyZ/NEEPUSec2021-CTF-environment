<?php
/* Smarty version 3.1.38, created on 2021-04-22 20:32:12
  from '2be44e359724bf19f8969045831d84e8849349a7' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.38',
  'unifunc' => 'content_60816ccc857e42_90456596',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60816ccc857e42_90456596 (Smarty_Internal_Template $_smarty_tpl) {
?>恭喜 1'='0 获得了胜利<?php }
}
