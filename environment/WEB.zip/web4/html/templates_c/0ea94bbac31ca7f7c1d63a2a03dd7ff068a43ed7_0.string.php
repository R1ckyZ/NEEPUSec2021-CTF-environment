<?php
/* Smarty version 3.1.38, created on 2021-04-23 10:58:09
  from '0ea94bbac31ca7f7c1d63a2a03dd7ff068a43ed7' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.38',
  'unifunc' => 'content_608237c1241c61_97720301',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_608237c1241c61_97720301 (Smarty_Internal_Template $_smarty_tpl) {
?>恭喜 <?php ob_start();
echo assert($_smarty_tpl->tpl_vars['_GET']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_a']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_a']->value['index'] : null)]);
$_prefixVariable1 = ob_get_clean();
echo $_prefixVariable1;?>
'='0 获得了胜利<?php }
}
