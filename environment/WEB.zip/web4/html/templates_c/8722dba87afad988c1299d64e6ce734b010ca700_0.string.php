<?php
/* Smarty version 3.1.38, created on 2021-04-22 13:43:03
  from '8722dba87afad988c1299d64e6ce734b010ca700' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.38',
  'unifunc' => 'content_60810ce75a3b55_57782962',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60810ce75a3b55_57782962 (Smarty_Internal_Template $_smarty_tpl) {
?>恭喜 1 获得了胜利<?php }
}
