<?php
/* Smarty version 3.1.38, created on 2021-04-22 20:56:34
  from 'd89d1e3d7242cdf3d8e8ab7745728c96c1df01ea' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.38',
  'unifunc' => 'content_60817282470640_94613801',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60817282470640_94613801 (Smarty_Internal_Template $_smarty_tpl) {
?>恭喜 <?php ob_start();
echo var_dump(getcwd("/"));
$_prefixVariable1 = ob_get_clean();
echo $_prefixVariable1;?>
//'='0 获得了胜利<?php }
}
