<?php
/* Smarty version 3.1.38, created on 2021-04-22 21:00:51
  from '4a62c664ec92c430ed4e0d2efbbc8ac894dd7ea7' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.38',
  'unifunc' => 'content_608173832ebd31_84592683',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_608173832ebd31_84592683 (Smarty_Internal_Template $_smarty_tpl) {
?>恭喜 <?php ob_start();
echo phpinfo();
$_prefixVariable1 = ob_get_clean();
echo $_prefixVariable1;?>
//'='0 获得了胜利<?php }
}
