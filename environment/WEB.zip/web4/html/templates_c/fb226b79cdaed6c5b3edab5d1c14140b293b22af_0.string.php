<?php
/* Smarty version 3.1.38, created on 2021-04-22 13:42:54
  from 'fb226b79cdaed6c5b3edab5d1c14140b293b22af' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.38',
  'unifunc' => 'content_60810cdee65277_36486923',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60810cdee65277_36486923 (Smarty_Internal_Template $_smarty_tpl) {
?>恭喜  获得了胜利<?php }
}
