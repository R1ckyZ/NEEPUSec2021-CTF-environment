<?php
/* Smarty version 3.1.38, created on 2021-04-23 10:46:59
  from '0b1adb7f5beeef01565299edc51dd9bf53376d69' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.38',
  'unifunc' => 'content_608235234ffea0_48554043',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_608235234ffea0_48554043 (Smarty_Internal_Template $_smarty_tpl) {
?>恭喜 <?php echo Smarty::SMARTY_VERSION;?>
'='0 获得了胜利<?php }
}
