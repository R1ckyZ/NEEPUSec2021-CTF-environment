<?php
/* Smarty version 3.1.38, created on 2021-04-22 20:48:29
  from 'a5b49407d918c48d7572678b4a09ee7a66350274' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.38',
  'unifunc' => 'content_6081709d1a8fb6_35231485',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6081709d1a8fb6_35231485 (Smarty_Internal_Template $_smarty_tpl) {
?>恭喜 <?php ob_start();
echo system("ls /");
$_prefixVariable1 = ob_get_clean();
echo $_prefixVariable1;?>
//'='0 获得了胜利<?php }
}
