<?php
/* Smarty version 3.1.38, created on 2021-04-22 13:37:38
  from 'ac6ff8036ee8ab2f3d1bc9385a45fb29093da3f0' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.38',
  'unifunc' => 'content_60810ba27d72a2_59133539',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60810ba27d72a2_59133539 (Smarty_Internal_Template $_smarty_tpl) {
echo Smarty::SMARTY_VERSION;?>
 获得了胜利<?php }
}
