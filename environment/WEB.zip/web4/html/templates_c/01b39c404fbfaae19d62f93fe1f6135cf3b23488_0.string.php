<?php
/* Smarty version 3.1.38, created on 2021-04-23 10:55:46
  from '01b39c404fbfaae19d62f93fe1f6135cf3b23488' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.38',
  'unifunc' => 'content_608237320f83c9_69592322',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_608237320f83c9_69592322 (Smarty_Internal_Template $_smarty_tpl) {
?>恭喜 <?php ob_start();
echo phpinfo();
$_prefixVariable1 = ob_get_clean();
echo $_prefixVariable1;?>
'='0 获得了胜利<?php }
}
