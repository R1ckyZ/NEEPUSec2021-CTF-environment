<?php
/* Smarty version 3.1.38, created on 2021-04-22 13:37:48
  from '398230c7727f1ce62739fb25a9b89193f711c3c0' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.38',
  'unifunc' => 'content_60810baca79de7_66731742',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60810baca79de7_66731742 (Smarty_Internal_Template $_smarty_tpl) {
?>恭喜 <?php echo Smarty::SMARTY_VERSION;?>
 获得了胜利<?php }
}
