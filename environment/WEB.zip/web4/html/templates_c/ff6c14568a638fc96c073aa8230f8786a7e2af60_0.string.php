<?php
/* Smarty version 3.1.38, created on 2021-04-23 11:19:08
  from 'ff6c14568a638fc96c073aa8230f8786a7e2af60' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.38',
  'unifunc' => 'content_60823caceec3d1_43402136',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60823caceec3d1_43402136 (Smarty_Internal_Template $_smarty_tpl) {
?>恭喜 <?php ob_start();
echo exec("dir<>./");
$_prefixVariable1 = ob_get_clean();
echo $_prefixVariable1;?>
'='0 获得了胜利<?php }
}
