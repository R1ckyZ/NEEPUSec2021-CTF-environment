<?php
/* Smarty version 3.1.38, created on 2021-04-22 20:47:33
  from '999be4637283f386df34db0240ea1453666bd0d7' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.38',
  'unifunc' => 'content_60817065903d12_73281625',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60817065903d12_73281625 (Smarty_Internal_Template $_smarty_tpl) {
?>恭喜 <?php if ('phpinfo') {
}?>//'='0 获得了胜利<?php }
}
