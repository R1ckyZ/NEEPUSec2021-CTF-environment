#!/usr/bin/env sh
mysql -e "create database neepuctf; use neepuctf;source /db.sql;" -uroot -proot
echo $FLAG > /This_is_your_Flag

export FLAG=not_flag
FLAG=not_flag

rm -rf /db.sql
rm -rf /flag.sh
