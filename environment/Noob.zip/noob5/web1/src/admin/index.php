<!DOCTYPE html>
<html>
<head>
<title>Home</title>
<META HTTP-EQUIV="Refresh" CONTENT="0;URL=dist/html/index.php">
</head>
<body>

</body>
</html>
