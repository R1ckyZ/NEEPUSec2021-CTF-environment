<?php
session_start();
if ($_POST['username'] === 'neepusec' && $_POST['password'] === 'd1107b17d9f283ff44fc7c535029ae24') {
    $_SESSION['admin'] = 1;
    Header("Location:admin/index.php");
}
else{
    Header("Location:index.php");
}