#!/usr/bin/env sh
echo '<?php $flag="'$FLAG'";?>' > /var/www/html/n33pufl4g.php

export FLAG=not_flag
FLAG=not_flag

rm -rf /flag.sh
