<?php
session_start();
?>
<div class="text" style=" text-align:center;">
    <body bgcolor="pink">
    <title>Python Game</title>
    <h1>算数竞赛</h1>
    <h2>一共100题，全部答对即可获得flag</h2>
    <style type="text/css">
        #divcss5{
            position: absolute;
            top: 65%;
            left: 50%;
            margin: -150px 0 0 -200px;
            width: 400px;
            height: 300px;
            //border: 1px solid red;
        }
        #timerSeconds{
            position: absolute;
            top: 65%;
            left: 50%;
            margin: -70px 0 0 -200px;
            width: 400px;
            height: 300px;
            //border: 1px solid red;
        }
    </style>
    <div id="divcss5" style="color:#ffffff; font-size: 70"></div>
    <span> </span>
    <div id="timerSeconds" style="color:red;  font-size: 70"></div>
    <?php
    include('n33pufl4g.php');
    if ($_SESSION['flag'] < 50) {
        $a = rand(1,10000000);
        $c = rand(1,10000000);
        $add = $a + $c;
        $del = $a - $c;
        $mult = $a * $c;
        $r = rand(0, 2);
        $char = [$add, $del, $mult];
        $ans = $char[$r];

        if ($r == 0) {
            $b = '+';
        } elseif ($r == 1) {
            $b = '-';
        } else {
            $b = '*';
        }

        echo '<p>' . $a . '&nbsp' . $b . '&nbsp' . $c . '&nbsp=&nbsp?</p><br />';
    }
    else {
        $a = rand(1,100);
        $c = rand(1,10);
        $doub = pow($a, $c);
        $remain = $a % $c;
        $r = rand(0,1);
        $char = [$doub, $remain];
        $ans = $char[$r];

        if ($r == 0) {
            $b = '**';
        } else {
            $b = '%';
        }
        echo '<p>' . $a . '&nbsp' . $b . '&nbsp' . $c . '&nbsp=&nbsp?</p><br />';
    }
    echo '<form method="post" οnsubmit="return beforeSubmit()">
        answer：<input id="answer" type="answer" name="answer"/>
        <input type="submit" value="摊牌了" />
    </form>';

    if($_SESSION['answer'] == $_POST['answer']) {
        $_SESSION['flag'] += 1;
        echo '<font color="green"><h3>success</h3></font>';
    } else {
        $_SESSION['flag'] = 0;
        echo '<font color="red"><h3>wrong</h3></font>';
    }

    $_SESSION['answer'] = $ans;

    if($_SESSION['flag'] > 100) {
        echo $flag;
    }
    ?>
    <h1>1s思考，9s交答案2333</h1>
    <meta http-equiv="refresh" content="10">
    <script type="text/javascript">
        var maxtime = 1 * 9; //10s，按秒计算，自己调整!
        function CountDown() {
            if (maxtime >= 0) {
                msg = Math.floor(maxtime / 60);
                secondsMsg = Math.floor(maxtime % 60);

                if (msg == 0 ) {
                    document.all["divcss5"].innerHTML = "";
                } else if (msg < 10) {
                    document.all["divcss5"].innerHTML = "0" + msg;
                } else {
                    document.all["divcss5"].innerHTML = msg;
                }

                document.all["timerSeconds"].innerHTML = secondsMsg;

                --maxtime;
            } else {
                clearInterval(timer);
                document.all["timerSeconds"].innerHTML = "Death";
            }
        }
        timer = setInterval("CountDown()", 1000);
    </script>
