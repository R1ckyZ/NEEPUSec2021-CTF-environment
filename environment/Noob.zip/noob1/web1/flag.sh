#!/usr/bin/env sh
echo "尝试访问根目录" > /var/www/html/hint.txt
echo "可以尝试grep" > /flag 
echo $FLAG > /etc/neepu.conf

export FLAG=not_flag
FLAG=not_flag

rm -rf /flag.sh
